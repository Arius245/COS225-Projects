package demo;

// Name: Arius Ahmad
// Class: COS 225 Section 0001
// Date: 2/24/23
// Collaboration Statement: I worked with Teddy Morin and Vincent Lin

public class Patient {
	int ID;
	double cafLevel;
	
	public Patient() {
		ID = 0;
		cafLevel = 0.0;
	}
	
	public Patient(int ID, double cafLevel) {
		this.ID = ID;
		this.cafLevel = cafLevel;
	}
}
