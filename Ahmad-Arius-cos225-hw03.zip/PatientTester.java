package demo;

//Name: Arius Ahmad
//Class: COS 225 Section 0001
//Date: 2/24/23
//Collaboration Statement: I worked with Teddy Morin and Vincent Lin

public class PatientTester {

	public static void main(String[] args) {
		PatientManager pats = new PatientManager();
		System.out.println(pats.toString());
		
		Patient pat1 = new Patient(1, 100.0);
		Patient pat2 = new Patient(2, 200.0);
		Patient pat3 = new Patient(3, 300.0);
		Patient pat4 = new Patient(4, 400.0);
		pats.addPatient(pat1);
		pats.addPatient(pat2);
		pats.addPatient(pat3);
		pats.addPatient(pat4);
		
		System.out.println(pats.toString());
		
		pats.caffeineAbsorption();
		
		System.out.println(pats.toString());
		
		pats.removePatient(3);
		
		System.out.println(pats.toString());
	}

}
