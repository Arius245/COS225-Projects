package demo;

//Name: Arius Ahmad
//Class: COS 225 Section 0001
//Date: 2/24/23
//Collaboration Statement: I worked with Teddy Morin and Vincent Lin

public class PatientManager {
	Patient[] pats;
	int freeSpots;
	
	public PatientManager() {
		pats = new Patient[10];
		freeSpots = 10;
	}
	
	public int addPatient(Patient varPat) {
		for (int i = 0; i < 10; i++) {
			if (pats[i] == null) {
				freeSpots--;
				pats[i] = varPat;
				return i;
			}
		}
		return 10;
	}
	
	public Patient removePatient(int index) {
		Patient removedPat = pats[index];
		pats[index] = null;
		freeSpots++;
		return removedPat;
	}
	
	public void caffeineAbsorption() {
		for (int i = 0; i<10; i++) {
			if (pats[i] != null) {
				pats[i].cafLevel -= 130.0;
				if (pats[i].cafLevel <= 0.0) {
					pats[i] = null;
					freeSpots++;
				}
			}
		}
	}
	
	public String toString() {
		String a = "";
		for (int i = 0; i < 10; i++) {
			if (freeSpots != 10) {
				if (pats[i] != null) {
					a += pats[i].ID + " " + pats[i].cafLevel + "\n";
				}
			}
			else {
				return "Empty";
			}
		}
		return a;
	}
}
