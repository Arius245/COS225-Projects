package demo;

//Name: Arius Ahmad
//Class: COS 225 Section 0001
//Date: 3/20/23
//Collaboration Statement: I worked with McKade Wing (mckade.wing@maine.edu)

public class CustomerOrder {
	
	String name;
	String date;
	int quantity;
	
	public CustomerOrder() {
		name = "";
		date = "";
		quantity = 0;
	}
	
	public CustomerOrder(String name, String date, int quantity) {
		this.name = name;
		this.date = date;
		this.quantity = quantity;
	}
	
	public void shipProduct() {
		if (quantity-1 < 0) {
			return;
		}
		else {
			quantity--;
		}
	}
}
