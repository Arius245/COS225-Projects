package demo;

public class DoubleLinkedNode<T> {

	private T element;
	private DoubleLinkedNode<T> next = null;
	private DoubleLinkedNode<T> prev = null;
	
	public DoubleLinkedNode(T data){
		this.element = data;
	}

	public DoubleLinkedNode<T> getPrev() {
		return prev;
	}

	public void setPrev(DoubleLinkedNode<T> prev) {
		this.prev = prev;
	}

	public T getElement() {
		return element;
	}

	public void setElement(T element) {
		this.element = element;
	}

	public DoubleLinkedNode<T> getNext() {
		return next;
	}

	public void setNext(DoubleLinkedNode<T> next) {
		this.next = next;
	}
	
	public String toString() {
		return element.toString();
	}
	
}
