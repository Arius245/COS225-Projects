package demo;

//Name: Arius Ahmad
//Class: COS 225 Section 0001
//Date: 3/22/23
//Collaboration Statement: I worked with McKade Wing (mckade.wing@maine.edu)

public class OrderTester {

	public static void main(String[] args) {
		OrderQueue order = new OrderQueue(14);
		order.addOrder("custom1", "1/1/1", 5);
		order.addOrder("custom2", "1/2/1", 5);
		order.addOrder("custom3", "1/3/1", 8);
		System.out.println(order.toString());
		
		order.sellStock();
		System.out.println(order.toString());
		
		order.addStock(10);
		order.addOrder("custom4", "1/4/1", 3);
		order.addOrder("custom5", "1/5/1", 3);
		order.addOrder("custom6", "1/6/1", 5);
		order.sellStock();
		System.out.println(order.toString());
	}

}
