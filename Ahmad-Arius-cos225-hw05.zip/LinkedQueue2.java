package demo;

public class LinkedQueue2<T> implements Queue<T> {
	private DoubleLinkedNode<T> head;
	private DoubleLinkedNode<T> tail;
	private int size = 0;
	
	//O(1)
	public void enqueue(T element) {
		if (head == null) {
			head = new DoubleLinkedNode<T>(element);
			tail = head;
			size++;
		}
		else if (head == tail) {
			DoubleLinkedNode<T> temp = new DoubleLinkedNode<T>(element);
			temp.setNext(head);
			head = temp;
			tail = head.getNext();
			tail.setPrev(head);
			size++;
		}
		else {
			DoubleLinkedNode<T> temp = new DoubleLinkedNode<T>(element);
			temp.setNext(head);
			head = temp;
			head.getNext().setPrev(head);
			size++;
		}
		
	}

	//O(1)
	public T dequeue() {
		if (head == null) {
			return null;
		}
		else if (head == tail) {
			T temp = head.getElement();
			head = null;
			tail = null;
			size--;
			return temp;
		}
		else {
			T temp = tail.getElement();
			tail = tail.getPrev();
			tail.setNext(null);
			size--;
			return temp;
		}
	}

	//O(1)
	public T getFront() {
		return tail.getElement();
	}

	//O(1)
	public boolean isEmpty() {
		return head == null;
	}

	//O(1)
	public int size() {
		return size;
	}

}

