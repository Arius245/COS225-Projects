package demo;

//Name: Arius Ahmad
//Class: COS 225 Section 0001
//Date: 3/22/23
//Collaboration Statement: I worked with McKade Wing (mckade.wing@maine.edu)

public class OrderQueue {
	LinkedQueue2<CustomerOrder> link;
	int stock;
	int size;
	
	public OrderQueue() {
		link = new LinkedQueue2<CustomerOrder>();
		stock = 0;
		size = link.size();
	}
	
	public OrderQueue(int stock) {
		link = new LinkedQueue2<CustomerOrder>();
		this.stock = stock;
		size = link.size();
	}
	
	public void addOrder(String name, String date, int quantity) {
		CustomerOrder custom = new CustomerOrder(name,date,quantity);
		link.enqueue(custom);
	}
	
	public void addStock(int addend) {
		stock+=addend;
	}
	
	public void doOrder() {
		link.getFront().quantity--;
		stock--;
		if (link.getFront().quantity == 0) {
			link.dequeue();
		}
	}
	
	public void sellStock() {
		while(stock > 0) {
			doOrder();
		}
	}
	
	public String toString() {
		return "" + link.getFront().quantity;
	}
}
