package demo;

//Name: Arius Ahmad
//Class: COS 225 Section 0001
//Date: 4/17/23
//Collaboration Statement: I worked with no one

//import java.util.Scanner;

public class MorseTester {

	public static void main(String[] args) {
		MorseTree tree = new MorseTree();
		
		tree.root.insertLeft("e");
			tree.root.getLeft().insertLeft("i");
				tree.root.getLeft().getLeft().insertLeft("s");
					tree.root.getLeft().getLeft().getLeft().insertLeft("h");
					tree.root.getLeft().getLeft().getLeft().insertRight("v");
				tree.root.getLeft().getLeft().insertRight("u");
					tree.root.getLeft().getLeft().getRight().insertLeft("f");
			tree.root.getLeft().insertRight("a");
				tree.root.getLeft().getRight().insertLeft("r");
					tree.root.getLeft().getRight().getLeft().insertLeft("l");
				tree.root.getLeft().getRight().insertRight("w");
					tree.root.getLeft().getRight().getRight().insertLeft("p");
					tree.root.getLeft().getRight().getRight().insertRight("j");
		
		tree.root.insertRight("t");
			tree.root.getRight().insertLeft("n");
				tree.root.getRight().getLeft().insertLeft("d");
					tree.root.getRight().getLeft().getLeft().insertLeft("b");
					tree.root.getRight().getLeft().getLeft().insertRight("x");
				tree.root.getRight().getLeft().insertRight("k");
					tree.root.getRight().getLeft().getRight().insertLeft("c");
					tree.root.getRight().getLeft().getRight().insertRight("y");
			tree.root.getRight().insertRight("m");
				tree.root.getRight().getRight().insertLeft("g");
					tree.root.getRight().getRight().getLeft().insertLeft("z");
					tree.root.getRight().getRight().getLeft().insertRight("q");
				tree.root.getRight().getRight().insertRight("o");
		
		System.out.println(tree.getPre());
		System.out.println(tree.getPost());
		System.out.println();
		
		//English to Morse Code
//		Scanner myObj = new Scanner(System.in);
//		System.out.print("Input: ");
//		String engWord = myObj.nextLine();
//		System.out.print("Output: |");
//		System.out.print(tree.engToMorse(engWord));
		
		String engToMor = tree.engToMorse("The quick fox");
		System.out.println(engToMor);
		
		//Morse Code to English
//		System.out.println();
//		Scanner myObj2 = new Scanner(System.in);
//		System.out.print("Input: ");
//		String morseWord = myObj2.nextLine();
//		System.out.print("Output: ");
//		System.out.print(tree.morseToEng(morseWord));
		
		System.out.println(tree.morseToEng(engToMor));
	}
}
