package demo;

//Name: Arius Ahmad
//Class: COS 225 Section 0001
//Date: 4/17/23
//Collaboration Statement: I worked with no one

public class MorseTree {
	TreeNode<String> root;
	
	public MorseTree() {
		root = new TreeNode<String>("_");
	}
	
	public String getPre() {
		return root.preorder();
	}
	
	public String getPost() {
		return root.postorder();
	}
	
	public String engToMorse(String word) {
		String lowerWord = word.toLowerCase();
		String newWord = "";
		for (int i = 0; i < lowerWord.length(); i++) {
			//translate to morse code
			switch (lowerWord.charAt(i)) {
				case('e'):
					newWord += " o |";
					break;
				case('t'):
					newWord += " - |";
					break;
				case('i'):
					newWord += " o o |";
					break;
				case('a'):
					newWord += " o - |";
					break;
				case('n'):
					newWord += " - o |";
					break;
				case('m'):
					newWord += " - - |";
					break;
				case('s'):
					newWord += " o o o |";
					break;
				case('u'):
					newWord += " o o - |";
					break;
				case('r'):
					newWord += " o - o |";
					break;
				case('w'):
					newWord += " o - - |";
					break;
				case('d'):
					newWord += " - o o |";
					break;
				case('k'):
					newWord += " - o - |";
					break;
				case('g'):
					newWord += " - - o |";
					break;
				case('o'):
					newWord += " - - - |";
					break;
				case('h'):
					newWord += " o o o o |";
					break;
				case('v'):
					newWord += " o o o - |";
					break;
				case('f'):
					newWord += " o o - o |";
					break;
				case('l'):
					newWord += " o - o o |";
					break;
				case('p'):
					newWord += " o - - o |";
					break;
				case('j'):
					newWord += " o - - - |";
					break;
				case('b'):
					newWord += " - o o o |";
					break;
				case('x'):
					newWord += " - o o - |";
					break;
				case('c'):
					newWord += " - o - o |";
					break;
				case('y'):
					newWord += " - o - - |";
					break;
				case('z'):
					newWord += " - - o o |";
					break;
				case('q'):
					newWord += " - - o - |";
					break;
				default:
					newWord += "";
			}
		}
		return newWord;
	}
	
	public String morseToEng(String word) {
		String temp = "";
		String engWord = "";
		String morse = word.toLowerCase();
		for (int i = 1; i<morse.length(); i++) {
			if(morse.charAt(i) == ' ') {
				continue;
			}
			else if(morse.charAt(i) != '|') {
				temp += morse.charAt(i);
			}
			else {
				//translate to english
				switch (temp) {
					case("o"):
						engWord += "e";
						break;
					case("-"):
						engWord += "t";
						break;
					case("oo"):
						engWord += "i";
						break;
					case("o-"):
						engWord += "a";
						break;
					case("-o"):
						engWord += "n";
						break;
					case("--"):
						engWord += "m";
						break;
					case("ooo"):
						engWord += "s";
						break;
					case("oo-"):
						engWord += "u";
						break;
					case("o-o"):
						engWord += "r";
						break;
					case("o--"):
						engWord += "w";
						break;
					case("-oo"):
						engWord += "d";
						break;
					case("-o-"):
						engWord += "k";
						break;
					case("--o"):
						engWord += "g";
						break;
					case("---"):
						engWord += "o";
						break;
					case("oooo"):
						engWord += "h";
						break;
					case("ooo-"):
						engWord += "v";
						break;
					case("oo-o"):
						engWord += "f";
						break;
					case("o-oo"):
						engWord += "l";
						break;
					case("o--o"):
						engWord += "p";
						break;
					case("o---"):
						engWord += "j";
						break;
					case("-ooo"):
						engWord += "b";
						break;
					case("-oo-"):
						engWord += "x";
						break;
					case("-o-o"):
						engWord += "c";
						break;
					case("-o--"):
						engWord += "y";
						break;
					case("--oo"):
						engWord += "z";
						break;
					case("--o-"):
						engWord += "q";
						break;
					default:
						engWord += "";
				}
				temp = "";
			}
		}
		return engWord;
	}
}
