package hw2;

public class Tree {
	int ID;
	int age;
	String species;
	
	public Tree() {
		ID = 0;
		age = 0;
		species = "Standard";
	}
	
	public Tree(int ID, int age, String species) {
		this.ID = ID;
		this.age = age;
		this.species = species;
	}
}
