package hw2;

public class Grove {
	Tree[] trees;
	String groveName;
	
	public Grove() {
		trees = new Tree[8];
		groveName = "Standard";
	}
	
	public Grove(String groveName) {
		trees = new Tree[8];
		this.groveName = groveName;
	}
	
	public int plant(Tree varTree) {
		for (int i = 0; i < 8; i++) {
			if (trees[i] == null) {
				trees[i] = varTree;
				return i;
			}
		}
		return -1;
	}
	
	public Tree unplant(int index) {
		Tree removedTree = trees[index];
		trees[index] = null;
		return removedTree;
	}
	
	public String toString() {
		int counter = 0;
		for (int i = 0; i < 8; i++) {
			if (trees[i] != null) {
				counter++;
			}
		}
		return "" + counter;
	}
}
