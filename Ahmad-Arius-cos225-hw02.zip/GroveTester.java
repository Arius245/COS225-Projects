package hw2;

public class GroveTester {

	public static void main(String[] args) {
		Grove grove1 = new Grove("Grove 1");
		System.out.println(grove1);
		
		Tree tree1 = new Tree(1,37,"Pine");
		grove1.plant(tree1);
		Tree tree2 = new Tree(2,37,"Pine");
		grove1.plant(tree2);
		Tree tree3 = new Tree(3,37,"Pine");
		grove1.plant(tree3);
		Tree tree4 = new Tree(4,37,"Pine");
		grove1.plant(tree4);
		Tree tree5 = new Tree(5,37,"Pine");
		grove1.plant(tree5);
		Tree tree6 = new Tree(6,37,"Pine");
		grove1.plant(tree6);
		Tree tree7 = new Tree(7,37,"Pine");
		grove1.plant(tree7);
		
		System.out.println(grove1);
		
		grove1.unplant(3);
		grove1.unplant(5);
		
		System.out.println(grove1);
		
		Tree tree8 = new Tree(8,13,"Spruce");
		grove1.plant(tree8);
		
		System.out.println(grove1);
	}

}
