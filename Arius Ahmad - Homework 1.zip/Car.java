package homework1;

public class Car {
	String manufacturer;
	String color;
	boolean handicap;
	
	public Car(String manufacturer, String color, boolean handicap) {
		this.manufacturer = manufacturer;
		this.color = color;
		this.handicap = handicap;
	}
}