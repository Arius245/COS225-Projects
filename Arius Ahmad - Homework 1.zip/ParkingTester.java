package homework1;

public class ParkingTester {

	public static void main(String[] args) {
		ParkingLot lot = new ParkingLot();
		Car handCar = new Car("Infiniti", "Red", true);
		Car regCar = new Car("Cadiliac", "Grey", false);
		
		System.out.println(lot.toString());
		
		int handCarIndex = lot.parkCar(handCar);
		
		System.out.println(lot.toString());
		
		lot.parkCar(regCar);
		
		System.out.println(lot.toString());
		
		lot.removeCar(handCarIndex);
		
		System.out.println(lot.toString());
	}

}
