package homework1;

public class ParkingLot 
{
	ParkingSpot[] spots;
	
	public ParkingLot() 
	{
		spots = new ParkingSpot[20];
		for (int i = 0; i < 20; i++) 
		{
			if (i < 4) 
			{
				spots[i] = new ParkingSpot(true);
			}
			
			else 
			{
				spots[i] = new ParkingSpot(false);
			}
		}
	}
	
	public int parkCar(Car varCar) 
	{
		for (int i = 0; i < 20; i ++) {
			if (spots[i].parkedCar == null) {
				if (varCar.handicap == true) {
					// park car in spot
					spots[i].parkedCar = varCar;
					return i;
				}
			 	else if(varCar.handicap == false && i >= 4) {
			 		spots[i].parkedCar = varCar;
					return i;
			 	}
			} 
		}
		return 10;
	}
	
	public Car removeCar(int spotIndex) {
		Car removedCar = spots[spotIndex].parkedCar;
		spots[spotIndex].parkedCar = null;
		return removedCar;
	}
	
	public String toString() 
	{
		int handCount = 0;
		int lotCount = 0;
		
		for (int i = 0; i < 20; i ++) {
			if (spots[i].parkedCar == null) {
				if (spots[i].handicap == true) {
					handCount++;
				}
				else {
					lotCount++;
				}
			}
		}
		//for
		//if (is a spot null or not)
		//		if (is a spot handicap or not)
		//keep two separate counters
		return "" + handCount + " " + lotCount; // "" + number  <= converts to string
	}
}
