package homework1;

public class ParkingSpot {
	Car parkedCar;
	boolean handicap;
	
	public ParkingSpot(boolean handicap) {
		this.handicap = handicap;
	}
	
}
