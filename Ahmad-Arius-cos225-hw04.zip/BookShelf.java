package demo;

import java.util.ArrayList;

//Name: Arius Ahmad
//Class: COS 225 Section 0001
//Date: 2/28/23
//Collaboration Statement: I worked with no one

public class BookShelf {
	char firstLetter;
	ArrayList<Book> books;
	
	public BookShelf() {
		firstLetter = ' ';
		books = new ArrayList<Book>(8);
	}
	
	public char getFirstLetter() {
		return firstLetter;
	}
	
	public void setFirstLetter(char firstLetter) {
		this.firstLetter = firstLetter;
	}
	
	public ArrayList<Book> getList() {
		return books;
	}
	
	public void setList(ArrayList<Book> newShelf) {
		books = newShelf;
	}
	
	public void addBook(Book varBook) {
		if (firstLetter == varBook.title.charAt(0)) {
			books.add(varBook);
		}
		else {
			return;
		}
	}
	
	public void removeBook(Book varBook) {
		books.remove(varBook);
	}
	
	public String toString() {
		String returnedString = "";
		if (books.isEmpty() != true) {
			for (int i = 0; i < books.size(); i++) {
				returnedString += books.get(i).title + "   ";
			}
			return returnedString;
		}
		else {
			return "Empty";
		}
	}
}
