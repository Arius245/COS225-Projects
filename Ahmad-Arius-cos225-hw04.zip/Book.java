package demo;

//Name: Arius Ahmad
//Class: COS 225 Section 0001
//Date: 2/28/23
//Collaboration Statement: I worked with no one

public class Book {
	String title;
	String genre;
	
	public Book(String title, String genre) {
		this.title = title;
		this.genre = genre;
	}
	
	public String toString() {
		return title;
	}
}
