package demo;

//Name: Arius Ahmad
//Class: COS 225 Section 0001
//Date: 2/28/23
//Collaboration Statement: I worked with no one

public class LibraryTester {

	public static void main(String[] args) {
		BookShelf shelf1 = new BookShelf();
		shelf1.setFirstLetter('O');
		BookShelf shelf2 = new BookShelf();
		shelf2.setFirstLetter('T');
		
		System.out.println(shelf1.toString());
		System.out.println(shelf2.toString());
		
		Book book1 = new Book("The Heart of the Betrayed", "Fantasy");
		Book book2 = new Book("Our Hill of Stars", "Crime");
		Book book3 = new Book("One of a Kind", "Romance");
		Book book4 = new Book("The Vision of Roses", "Science Fiction");
		
		System.out.println(book1.toString());
		System.out.println(book2.toString());
		System.out.println(book3.toString());
		System.out.println(book4.toString());
		
		shelf1.addBook(book1);
		shelf1.addBook(book2);
		shelf1.addBook(book3);
		shelf1.addBook(book4);
		
		shelf2.addBook(book1);
		shelf2.addBook(book2);
		shelf2.addBook(book3);
		shelf2.addBook(book4);
		
		System.out.println(shelf1.toString());
		System.out.println(shelf2.toString());

	}

}
